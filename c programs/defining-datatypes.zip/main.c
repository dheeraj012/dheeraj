#include<stdio.h>
int main()
{
int a=57396;
long int b=12359;
unsigned int c=5739;
printf("a=%d",a);
printf("nb=%d",b);
printf("nc=%u",c);
printf("n&a=%d",a);
return 0;
}
